scalar_maximization
===================

.. automodule:: quantecon.optimize.scalar_maximization
    :members:
    :undoc-members:
    :show-inheritance:
