nelder_mead
===========

.. automodule:: quantecon.optimize.nelder_mead
    :members:
    :undoc-members:
    :show-inheritance:
