array
=====

.. automodule:: quantecon.util.array
    :members:
    :undoc-members:
    :show-inheritance:
