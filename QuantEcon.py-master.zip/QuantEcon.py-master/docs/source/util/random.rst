random
======

.. automodule:: quantecon.util.random
    :members:
    :undoc-members:
    :show-inheritance:
