common_messages
===============

.. automodule:: quantecon.util.common_messages
    :members:
    :undoc-members:
    :show-inheritance:
