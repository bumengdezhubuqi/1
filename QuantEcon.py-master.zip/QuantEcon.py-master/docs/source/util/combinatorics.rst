combinatorics
=============

.. automodule:: quantecon.util.combinatorics
    :members:
    :undoc-members:
    :show-inheritance:
