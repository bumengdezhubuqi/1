utilities
=========

.. automodule:: quantecon.game_theory.utilities
    :members:
    :undoc-members:
    :show-inheritance:
