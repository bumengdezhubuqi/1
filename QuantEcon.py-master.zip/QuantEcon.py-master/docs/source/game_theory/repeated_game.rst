repeated_game
=============

.. automodule:: quantecon.game_theory.repeated_game
    :members:
    :undoc-members:
    :show-inheritance:
