pure_nash
=========

.. automodule:: quantecon.game_theory.pure_nash
    :members:
    :undoc-members:
    :show-inheritance:
