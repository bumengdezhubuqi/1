bimatrix_generators
===================

.. automodule:: quantecon.game_theory.game_generators.bimatrix_generators
    :members:
    :undoc-members:
    :show-inheritance:
