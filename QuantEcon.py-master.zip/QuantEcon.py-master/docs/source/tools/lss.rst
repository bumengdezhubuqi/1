lss
===

.. automodule:: quantecon.lss
    :members:
    :undoc-members:
    :show-inheritance:
