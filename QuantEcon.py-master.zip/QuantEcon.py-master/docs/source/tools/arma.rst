arma
====

.. automodule:: quantecon.arma
    :members:
    :undoc-members:
    :show-inheritance:
