quadsums
========

.. automodule:: quantecon.quadsums
    :members:
    :undoc-members:
    :show-inheritance:
