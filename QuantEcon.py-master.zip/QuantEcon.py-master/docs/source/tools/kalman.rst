kalman
======

.. automodule:: quantecon.kalman
    :members:
    :undoc-members:
    :show-inheritance:
