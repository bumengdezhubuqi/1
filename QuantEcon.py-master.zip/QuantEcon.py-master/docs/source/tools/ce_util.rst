ce_util
=======

.. automodule:: quantecon.ce_util
    :members:
    :undoc-members:
    :show-inheritance:
