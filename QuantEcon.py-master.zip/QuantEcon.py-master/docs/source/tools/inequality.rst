inequality
==========

.. automodule:: quantecon.inequality
    :members:
    :undoc-members:
    :show-inheritance:
