lqcontrol
=========

.. automodule:: quantecon.lqcontrol
    :members:
    :undoc-members:
    :show-inheritance:
