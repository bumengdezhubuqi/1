quad
====

.. automodule:: quantecon.quad
    :members:
    :undoc-members:
    :show-inheritance:
