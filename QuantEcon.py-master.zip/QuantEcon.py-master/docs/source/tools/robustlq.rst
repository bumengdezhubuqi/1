robustlq
========

.. automodule:: quantecon.robustlq
    :members:
    :undoc-members:
    :show-inheritance:
