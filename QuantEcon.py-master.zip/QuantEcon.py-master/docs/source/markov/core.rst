core
====

.. automodule:: quantecon.markov.core
    :members:
    :undoc-members:
    :show-inheritance:
