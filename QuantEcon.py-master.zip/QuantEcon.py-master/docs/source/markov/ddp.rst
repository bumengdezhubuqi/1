ddp
===

.. automodule:: quantecon.markov.ddp
    :members:
    :undoc-members:
    :show-inheritance:
